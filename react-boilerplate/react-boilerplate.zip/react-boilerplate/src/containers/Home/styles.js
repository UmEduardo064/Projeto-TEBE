import styled from "styled-components";

export const Title = styled.h1`
    color: #fff;
    font-size: 28px;
    text-align: center;
`

export const MeuContainer = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;  
    flex-direction: column;
    padding-top: 100px;
    width: 100%;        
`
export const MeuFormulario = styled.form`
    display: flex;
    flex-direction: column;
    gap: 30px;
    padding: 30px;
    border-radius: 10px;
    background-color: #2e2d4e;
    max-width: 400px;
    width: 100%;
    margin-bottom: 20px;

`

export const BotaoCadastro = styled.button`
    border-radius: 30px;
    background-color: #8b8ae1;
    height: 40px;
    border: none;
    font-weight: bold;
    cursor: pointer;
    color: #fff;
    &:hover {
        opacity: 0.8;
    }
`

export const Input = styled.input`
    border: 1px solid #48456C;
    border-radius: 30px;
    height: 40px;
    background-color: #363653;
    color: #fff;
    font-size: 16px;
    padding-left: 16px;
    outline: none;


`
export const Card = styled.div`
    display: flex;
    justify-content: space-between;  
    background-color: #2e2d4e;
    margin: 10px;
    padding: 10px;
    width: 400px;
    border-radius: 10px; 
`

export const TextoCard = styled.p`
    color: #fff;
    font-weight: bold;
`

export const Spam = styled.span`
    font-weight: normal;
`

export const TrashButton = styled.button`
    background-color: transparent;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    &:hover {
        opacity: 0.5;
    }

`

export const ImagemBotao = styled.img`
    width: 40px;
    height: 40px;
`





