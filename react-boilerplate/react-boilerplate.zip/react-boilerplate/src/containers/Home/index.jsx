import Trash from '../../assets/trashicon.svg'
import { Card, MeuContainer, MeuFormulario, ImagemBotao, Input, Spam, TextoCard, Title, TrashButton, BotaoCadastro } from './styles'

function Home() {
    //#region Simulação de informações que virão de um banco de dados
    const users = [
        {
            id: "1qosk4",
            Usuario: "Lucas",
            Senha: "12345",
            Email: "lucas@email.com"
        },
        {
            id: "3adow2",
            Usuario: "Joao",
            Senha: "89123",
            Email: "jhon@email.com"
        },
        {
            id: "8aosm9",
            Usuario: "Lara",
            Senha: "98234",
            Email: "lara@email.com"
        }

    ]
    //#endregion

    return (
        <MeuContainer>
            <div className="container">
                <MeuFormulario>
                    <Title>Cadastro de Usuários</Title>
                    <Input placeholder="Digite seu usuário" name="Usuário" type="text" />
                    <Input placeholder="Digite seu email" name="Email" type="email" />
                    <Input placeholder="Digite sua senha" name="Senha" type="password" />
                    <BotaoCadastro type="button">Cadastrar</BotaoCadastro>
                </MeuFormulario>
            </div>

            {users.map(user => (
                <div key={user.id} >
                    <Card>
                        <div>
                            <TextoCard>Usuario <Spam>{user.Usuario}</Spam></TextoCard>
                            <TextoCard>Email <Spam>{user.Email}</Spam></TextoCard>
                            <TextoCard>Senha <Spam>{user.Senha}</Spam></TextoCard>
                        </div>
                        <TrashButton>
                            <ImagemBotao src={Trash} />
                        </TrashButton>
                    </Card>


                </div>

            ))}


        </MeuContainer>


    )
}
export default Home