import styled from "styled-components";

export const MyButton = styled.button `
    color: black;
    background-color: purple;
    width: 300px;
    height: 150px;

`
