import { MyButton } from "./styles"

function Button() 
{
    return (
        <div>
            <MyButton>Home</MyButton>
        </div>
    )
}

export default Button